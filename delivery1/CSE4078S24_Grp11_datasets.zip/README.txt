MultiNLI-TR 1.1

Thank you for your interest in our dataset.  The only difference between MultiNLI-TR 1.1 and MultiNLI-TR 1.0 is that the former one includes an extra field, namely "translation_annotations". This README file will include the notes regarding the cosmetic changes which don't effect its version.

Change logs
==============
13 Sept 2020 - Changed the file name pattern from mnli_{version}_{split_name}.tr.{extension} to multinli_tr_{version}_{split_name}.{extension}.
15 Sept 2020 - Included jsonl files.